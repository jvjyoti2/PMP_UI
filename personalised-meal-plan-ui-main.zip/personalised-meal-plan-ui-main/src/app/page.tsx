import Link from "next/link";

export default function Home() {
  return (
    <main className="grid min-h-full place-items-center">
      <div className="grid max-w-sm gap-2 bg-primary px-8 py-6 text-white">
        <h1 className="font-display text-2xl font-semibold">
          Personalised Meal Plan
        </h1>
        <p>Put together a perfect plan, personalised precisely for your pet.</p>
        <div className="flex py-2">
          <Link
            className="rounded-full bg-white px-4 py-2 text-primary"
            href="/meal-plan/basics"
          >
            Get started
          </Link>
        </div>
      </div>
    </main>
  );
}
