import { atom } from "jotai";
import { BasicFormData } from "../meal-plan/basics/BasicsForm";
import { HealthFormData } from "../meal-plan/health/HealthForm";
import { z } from "zod";

export type basicStateInterface = z.infer<typeof BasicFormData>;
type healthStateInterface = z.infer<typeof HealthFormData>;

const basicStateInit: basicStateInterface = {
  dog_name: "",
  dog_age_years: null,
  dog_age_months: null,
  dog_breed: "",
  dog_sex: "F",
  dog_sterilised: "false",
};

const healthStateInit: healthStateInterface = {
  dog_activity_level: 0,
  dog_body_condition: 0,
  dog_expected_adult_size: "",
  dog_lose_weight: "false",
  dog_weight: null,
  dog_working: "false",
};

const basicStateAtom = atom(basicStateInit);

const healthStateAtom = atom(healthStateInit);

export { basicStateAtom, healthStateAtom };
