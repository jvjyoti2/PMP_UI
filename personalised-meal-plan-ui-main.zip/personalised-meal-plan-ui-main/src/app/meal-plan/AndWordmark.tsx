export default function AndWordmark(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg aria-label="AND" viewBox="0 0 96 36" {...props}>
      <path
        d="M6 30h6v-3h12v3h6V18a12 12 0 0 0-24 0zm6-9h12v-3a6 6 0 0 0-12 0zM36 30h6V16l12 14h6V6h-6v14L42 6h-6zM66 30h12a12 12 0 0 0 0-24H66v6h3v12h-3zm9-6h3a6 6 0 0 0 0-12h-3z"
        fill="currentColor"
        fillRule="evenodd"
      />
    </svg>
  );
}
