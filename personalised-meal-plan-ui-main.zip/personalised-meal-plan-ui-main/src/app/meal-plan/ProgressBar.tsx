export default function ProgressBar({
  focusPage: focusPage,
}: {
  focusPage: string;
}) {
  interface labels {
    id: string;
    name: string;
  }
  [];

  const labels = [
    { id: "basics", name: "Basics" },
    { id: "health", name: "Health" },
    { id: "nutrition", name: "Nutrition" },
    { id: "diet-report", name: "Diet" },
  ];

  const focusStage = labels.findIndex((obj) => obj.id === focusPage);
  return (
    <nav aria-label="Meal plan progress" className="w-full">
      <ol className="grid grid-flow-col">
        {labels.map((label, idx) => {
          return (
            <li
              aria-current={idx === focusStage ? "step" : undefined}
              key={label.id}
              className="grid text-center text-primary"
            >
              <div className={`${idx <= focusStage ? "font-bold" : ""}`}>
                {label.name}
              </div>
              <div className="flex items-center">
                <div
                  className={`flex-1 border ${idx === 0 ? "invisible" : ""} ${
                    idx <= focusStage ? "" : "border-neutral-300"
                  }`}
                ></div>
                <div
                  className={`inline-block size-2 rounded border-2 ${
                    idx <= focusStage
                      ? "bg-current"
                      : "border-neutral-300 bg-transparent"
                  }`}
                ></div>
                <div
                  className={`flex-1 border ${
                    idx === labels.length - 1 ? "invisible" : ""
                  } ${idx < focusStage ? "" : "border-neutral-300"}`}
                ></div>
              </div>
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
