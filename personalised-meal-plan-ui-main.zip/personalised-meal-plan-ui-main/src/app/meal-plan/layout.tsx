"use client";

import AndWordmark from "./AndWordmark";
import { usePathname } from "next/navigation";
import ProgressBar from "./ProgressBar";

export default function Layout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const focusPage = pathname.substring(pathname.lastIndexOf("/") + 1);

  return (
    <>
      <header className="bg-neutral-100 px-2 pb-4 pt-12">
        <AndWordmark className="m-auto w-32 bg-primary text-white" />
      </header>
      <ProgressBar focusPage={focusPage}></ProgressBar>
      <div>{children}</div>
    </>
  );
}
