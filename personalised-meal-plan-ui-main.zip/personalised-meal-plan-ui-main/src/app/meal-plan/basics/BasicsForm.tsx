"use client";

import { Controller, SubmitHandler, useForm } from "react-hook-form";
import { clsx } from "clsx";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import ComboBoxWrapper from "@/app/ui/ComboBox";
import ErrorMessage from "@/app/ui/ErrorMessage";
import SexIcon from "./SexIcon";
import RadioButton from "@/app/ui/RadioButton";
import BackButton from "@/app/ui/BackButton";
import Button, { enumButtonType } from "@/app/ui/ContinueButton";
import CheckBox from "@/app/ui/CheckBox";
import PageErrorBox from "@/app/ui/PageErrorBox";
import Infobox from "@/app/ui/Infobox";
import FieldInfoBox from "@/app/ui/FieldInfoBox";
import { useAtom } from "jotai";
import { basicStateAtom } from "@/app/jotai/atoms";

interface FormProps {
  onBack: () => void;
  onSubmit: () => void;
}

export const BasicFormData = z.object({
  dog_name: z
    .string({ required_error: "This field is required" })
    .max(64, { message: "The maximum name length is 64 characters" })
    .regex(/^[A-Z]+$/i, { message: "Please use only letters" }),
  dog_age_years: z
    .number({
      required_error: "This field is required",
      invalid_type_error: "Years must be a whole number",
    })
    .int({ message: "Years must be a whole number" })
    .min(0, { message: "Years must be greater than or equal to 0" })
    .max(30, { message: "Years must be less than or equal to 30" })
    .nullable(),
  dog_age_months: z
    .number({
      required_error: "This field is required",
      invalid_type_error: "Months must be a whole number",
    })
    .int({ message: "Months must be a whole number" })
    .min(0, { message: "Months must be greater than or equal to 0" })
    .max(11, { message: "Months must be less than or equal to 11" })
    .nullable(),
  dog_breed: z.string().min(1, { message: "This field is required" }),
  dog_sex: z.enum(["M", "F"], {
    errorMap: () => ({
      message: "This field is required",
    }),
  }),
  dog_sterilised: z.enum(["false", "true"], {
    errorMap: () => ({
      message: "This field is required",
    }),
  }),
});

const dogBreedUnknown = "Mixed / Unknown";
const dogBreeds = [
  "Labrador Retriever",
  "French Bulldog",
  "German Shepherd",
  "Golden Retriever",
  "Bulldog",
  "Poodle",
  "Beagle",
  "Rottweiler",
  "German Shorthaired Pointer",
  "Dachshund",
  "Whippet",
];

type BasicsFormData = z.infer<typeof BasicFormData>;

export default function BasicsForm(props: FormProps) {
  const [basicState, setBasicState] = useAtom(basicStateAtom);
  const { onBack, onSubmit } = props;

  const values = basicState;

  const {
    watch,
    register,
    setValue,
    handleSubmit,
    control,
    formState: { errors, isValid, isSubmitted },
  } = useForm<BasicsFormData>({
    mode: "all",
    resolver: zodResolver(BasicFormData),
    values,
  });

  const submitForm: SubmitHandler<BasicsFormData> = (data) => {
    setBasicState(data);
    onSubmit();
  };

  const dogSexWatch = watch("dog_sex");
  const dogSterilisedWatch = watch("dog_sterilised");
  const dogBreedWatch = watch("dog_breed");

  const showFormError = isSubmitted && !isValid;

  return (
    <form className="grid max-w-md gap-4" onSubmit={handleSubmit(submitForm)}>
      {showFormError && (
        <PageErrorBox>
          Something looks strange... Please fix them before we continue.
        </PageErrorBox>
      )}
      <div className="grid-column items-start">
        <div className="mb-4">
          <Infobox>
            <p>
              If you have more than one pet, you can tell us about them later.
            </p>
          </Infobox>
        </div>
        <label htmlFor="dog-name" className="type-charcoal font-bold">
          What is your dog&apos;s name?
        </label>
        {errors.dog_name && (
          <ErrorMessage id="dog-name-error">
            {errors.dog_name.message}
          </ErrorMessage>
        )}
        <input
          className={clsx(
            "mt-2 h-12 w-full rounded border border-neutral-200 bg-white px-3 focus:outline-none",

            {
              "border-primary": errors.dog_name,
              "focus:border-neutral-500": !errors.dog_name,
            },
          )}
          id="dog-name"
          type="text"
          placeholder="Name"
          aria-invalid={errors.dog_name ? "true" : "false"}
          aria-errormessage="dog-name-error"
          {...register("dog_name", {
            setValueAs: (val) => val || undefined,
          })}
        />
      </div>
      <div className="grid-column items-start">
        <legend className="type-charcoal font-bold">
          How old is your dog?
        </legend>
        {errors.dog_age_years && (
          <ErrorMessage id="dog-age-years-error">
            {errors.dog_age_years.message}
          </ErrorMessage>
        )}
        {errors.dog_age_months && (
          <ErrorMessage id="dog-age-months-error">
            {errors.dog_age_months.message}
          </ErrorMessage>
        )}
        <div className="mt-2 flex gap-2">
          <label htmlFor="dog_age_years" className="sr-only">
            How many whole years old is your dog?
          </label>
          <input
            aria-label="dog-year-input"
            className={clsx(
              "h-12 w-3/6 rounded border border-neutral-200 bg-white px-3 focus:outline-none",
              {
                "border-primary": errors.dog_age_years,
                "focus:border-neutral-500": !errors.dog_age_years,
              },
            )}
            id="dog-age-years"
            placeholder="Years"
            aria-invalid={errors.dog_age_years ? "true" : "false"}
            aria-errormessage="dog-age-years-error"
            {...register("dog_age_years", {
              setValueAs: (val) => (val ? Number(val) : undefined),
            })}
          />
          <label htmlFor="dog-age-months" className="sr-only">
            How many months since your dog&apos;s last birthday?
          </label>
          <input
            className={clsx(
              "h-12 w-3/6 rounded border border-neutral-200 bg-white px-3 focus:outline-none",
              {
                "border-primary": errors.dog_age_months,
                "focus:border-neutral-500": !errors.dog_age_months,
              },
            )}
            id="dog-age-months"
            placeholder="Months"
            aria-label="dog-month-input"
            aria-invalid={errors.dog_age_months ? "true" : "false"}
            aria-errormessage="dog-age-months-error"
            {...register("dog_age_months", {
              setValueAs: (val) => (val ? Number(val) : undefined),
            })}
          />
        </div>
      </div>
      <div className="grid-colum items-start">
        <fieldset aria-describedby="dog-sex-error">
          <legend className="font-bold">Is your dog male or female?</legend>
          {errors.dog_sex && (
            <ErrorMessage id="dog-sex-error">
              {errors.dog_sex.message}
            </ErrorMessage>
          )}
          <div className="mt-2 flex">
            <input
              className="sr-only"
              id="dog_sex_male"
              type="radio"
              value="M"
              {...register("dog_sex")}
            />
            <label
              htmlFor="dog_sex_male"
              className="flex flex-col items-center pr-4"
            >
              <SexIcon sex={"M"} selected={dogSexWatch === "M"} />
              <span className="type-charcoal text-sm">Male</span>
            </label>
            <input
              className="sr-only"
              id="dog_sex_female"
              type="radio"
              value="F"
              {...register("dog_sex")}
            />
            <label
              htmlFor="dog_sex_female"
              className="flex flex-col items-center"
            >
              <SexIcon sex={"F"} selected={dogSexWatch === "F"} />
              <span className="text-sm">Female</span>
            </label>
          </div>
        </fieldset>
      </div>
      <div className="grid-column items-start">
        <Controller
          name="dog_breed"
          control={control}
          rules={{
            required: "Please select a breed",
          }}
          render={({ field: { onChange, onBlur } }) => (
            <ComboBoxWrapper
              id="dog-breed"
              placeholder="Choose your Breed"
              label="What is your dog's breed?"
              value={dogBreedWatch}
              disabled={dogBreedWatch === dogBreedUnknown}
              onChange={onChange}
              onBlur={onBlur}
              options={dogBreeds.map((item) => {
                return {
                  label: item,
                  value: item,
                };
              })}
              error={errors.dog_breed}
            />
          )}
        />
        <div className="mt-2">
          <input
            type="checkbox"
            className="sr-only"
            id="dog-breed-unknown"
            value="false"
          />
          <label
            htmlFor="dog-breed-unknown"
            className="flex flex-row items-center gap-2"
            onClick={() => {
              setValue(
                "dog_breed",
                dogBreedWatch === dogBreedUnknown ? "" : dogBreedUnknown,
              );
            }}
          >
            <CheckBox checked={dogBreedWatch === dogBreedUnknown} />
            <span className="text-sm">Mixed or unknown breed</span>
          </label>
        </div>
      </div>
      <div className="items-start">
        <fieldset aria-describedby="dog-sterilised-error">
          <legend className="font-bold">Is your dog spayed or neutered?</legend>
          {errors.dog_sterilised && (
            <ErrorMessage id="dog-sterilised-error">
              {errors.dog_sterilised.message}
            </ErrorMessage>
          )}
          <div className="mt-2">
            <FieldInfoBox summary="Understand why spaying or neutering is relevant">
              <p>
                Spayed or neutered dogs have reduced energy requirements and may
                be prone to weight gain. Owners should adjust their diet to
                prevent obesity.
              </p>
              <p>
                If a spayed or neutered dog becomes overweight, a veterinarian
                may recommend a weight loss diet. We recommend regular check-ups
                with your vet to monitor the dog&rsquo;s health and make any
                necessary diet adjustments.
              </p>
            </FieldInfoBox>
          </div>
          <div className="mt-2 space-y-1">
            <div>
              <input
                type="radio"
                className="sr-only"
                id="dog-sterilised-no"
                value="false"
                {...register("dog_sterilised")}
              />
              <label
                htmlFor="dog-sterilised-no"
                className="flex flex-row items-center gap-2"
              >
                <RadioButton checked={dogSterilisedWatch === "false"} />
                <span className="text-sm">No</span>
              </label>
            </div>
            <div>
              <input
                type="radio"
                className="sr-only"
                id="dog-sterilised-yes"
                value="true"
                {...register("dog_sterilised")}
              />
              <label
                htmlFor="dog-sterilised-yes"
                className="flex flex-row items-center gap-2"
              >
                <RadioButton checked={dogSterilisedWatch === "true"} />
                <span className="text-sm">Yes</span>
              </label>
            </div>
          </div>
        </fieldset>
      </div>
      <div className="flex flex-col-reverse md:flex-row">
        <BackButton id="basics-back-button" type="button" onClick={onBack} />
        <Button
          id="continue-button"
          label="Continue"
          type={enumButtonType.submit}
        />
      </div>
    </form>
  );
}
