"use client";

import BasicsForm from "@/app/meal-plan/basics/BasicsForm";
import HeadingMain from "@/app/ui/HeadingMain";
import { useRouter } from "next/navigation";

export default function MealPlanBasics() {
  const router = useRouter();
  const onBack = () => router.back();
  const onSubmit = () => router.push("/meal-plan/health");

  return (
    <>
      <div className="bg-neutral-100 px-2 pb-4 pt-12"></div>
      <main className="grid justify-center px-4 py-6">
        <HeadingMain>Basics</HeadingMain>
        <div className="mt-4 justify-between gap-2 md:mt-8">
          <BasicsForm onBack={onBack} onSubmit={onSubmit} />
        </div>
      </main>
    </>
  );
}
