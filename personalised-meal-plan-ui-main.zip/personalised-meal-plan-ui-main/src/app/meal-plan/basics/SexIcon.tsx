const SexIcon = (props: SexIconProps) => {
  const backgroundColour = props.selected ? "#FFFFFF" : "#EFEBE7";
  const strokeColour = props.selected ? "#D82036" : "#9D9D98";

  const maleSVG = (
    <g
      fill={strokeColour}
      fillRule="evenodd"
      clipPath="url(#a)"
      clipRule="evenodd"
    >
      <path d="M20.429 22.572a5 5 0 1 0 0 10 5 5 0 0 0 0-10Zm-6.429 5a6.429 6.429 0 1 1 12.857 0 6.429 6.429 0 0 1-12.857 0ZM26.143 14.714c0-.394.32-.714.714-.714h6.429c.394 0 .714.32.714.714v6.429a.714.714 0 0 1-1.429 0v-5.714h-5.714a.714.714 0 0 1-.714-.715Z" />
      <path d="M33.79 14.21a.714.714 0 0 1 0 1.01l-8.814 8.814a.714.714 0 1 1-1.01-1.01l8.815-8.815a.714.714 0 0 1 1.01 0Z" />
    </g>
  );

  const femaleSVG = (
    <g
      fill={strokeColour}
      fillRule="evenodd"
      clipPath="url(#a)"
      clipRule="evenodd"
    >
      <path d="M24 15.429A4.286 4.286 0 1 0 24 24a4.286 4.286 0 0 0 0-8.571Zm-5.714 4.285a5.714 5.714 0 1 1 11.428 0 5.714 5.714 0 0 1-11.428 0Z" />
      <path d="M24 24c.394 0 .714.32.714.714v8.572a.714.714 0 1 1-1.428 0v-8.572c0-.394.32-.714.714-.714Z" />
      <path d="M20.428 29.714c0-.394.32-.714.715-.714h5.714a.714.714 0 1 1 0 1.429h-5.714a.714.714 0 0 1-.715-.715Z" />
    </g>
  );

  const sexSVG = props.sex === "M" ? maleSVG : femaleSVG;

  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" fill="none">
      <circle
        cx="24"
        cy="24"
        r="23.5"
        fill={backgroundColour}
        stroke={strokeColour}
      />
      {sexSVG}
      <defs>
        <clipPath id="a">
          <path fill="#fff" d="M14 14h20v20H14z" />
        </clipPath>
      </defs>
    </svg>
  );
};

type SexIconProps = {
  sex: "M" | "F";
  selected?: boolean;
};

export default SexIcon;
