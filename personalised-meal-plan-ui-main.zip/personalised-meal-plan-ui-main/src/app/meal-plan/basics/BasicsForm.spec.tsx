import { test, expect, describe, jest, afterEach } from "@jest/globals";
import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import BasicsForm from "./BasicsForm";
import { mockRoutingProps } from "../../../../helpers/test_helpers";

const mockForm = (
  <BasicsForm
    onBack={mockRoutingProps.onBack}
    onSubmit={mockRoutingProps.onSubmit}
  />
);

afterEach(() => {
  jest.clearAllMocks();
});

describe("dog name", () => {
  const mockLongInput =
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras malesuada mauris odio, vitae tincidunt ex tempus vel.";

  test("dog name input has valid value", async () => {
    const user = userEvent.setup();
    const { container } = render(mockForm);
    await user.type(screen.getByLabelText("What is your dog's name?"), "Scout");
    expect(screen.getByLabelText("What is your dog's name?")).toBeValid();

    await user.clear(screen.getByLabelText("What is your dog's name?"));
    expect(screen.getByLabelText("What is your dog's name?")).toBeInvalid();
    const error = container.querySelector("#dog-name-error");
    expect(error).toHaveTextContent("This field is required");
  });

  test("dog name input has error message for exceeding maxLength", async () => {
    const user = userEvent.setup();
    const { container } = render(mockForm);
    await user.type(
      screen.getByLabelText("What is your dog's name?"),
      mockLongInput,
    );
    expect(screen.getByLabelText("What is your dog's name?")).toBeInvalid();
    const error = container.querySelector("#dog-name-error");
    expect(error).toHaveTextContent("The maximum name length is 64 characters");
  });

  test("dog name input has error message for using special characters or numbers", async () => {
    const user = userEvent.setup();
    const { container } = render(mockForm);
    await user.type(screen.getByLabelText("What is your dog's name?"), "@4875");
    expect(screen.getByLabelText("What is your dog's name?")).toBeInvalid();
    const error = container.querySelector("#dog-name-error");
    expect(error).toHaveTextContent("Please use only letters");
  });
});

describe("dog age", () => {
  test("should have years and months input for dog age", () => {
    render(mockForm);
    expect(screen.getByText("How old is your dog?")).toBeInTheDocument();
  });

  test("both years and months inputs are valid", async () => {
    const user = userEvent.setup();
    const { container } = render(mockForm);

    const dogYearInput = screen.getByLabelText("dog-year-input", {
      selector: "input",
    });
    const dogMonthInput = screen.getByLabelText("dog-month-input", {
      selector: "input",
    });

    await user.type(dogYearInput, "0");
    expect(dogYearInput).toBeValid();

    await user.type(dogMonthInput, "0");
    expect(dogMonthInput).toBeValid();

    await user.type(dogMonthInput, "10");
    expect(dogMonthInput).toBeValid();

    expect(
      container.querySelector("#dog-age-years-error"),
    ).not.toBeInTheDocument();
    expect(
      container.querySelector("#dog-age-months-error"),
    ).not.toBeInTheDocument();
  });

  test.each([
    { value: "a", error: "Years must be a whole number" },
    { value: "-1", error: "Years must be greater than or equal to 0" },
    { value: "31", error: "Years must be less than or equal to 30" },
    { value: "1.5", error: "Years must be a whole number" },
  ])("years input is invalid for '$value'", async ({ value, error }) => {
    const user = userEvent.setup();
    const { container } = render(mockForm);

    const dogYearInput = screen.getByLabelText("dog-year-input", {
      selector: "input",
    });

    await user.type(dogYearInput, value);
    expect(dogYearInput).toBeInvalid();

    expect(container.querySelector("#dog-age-years-error")).toHaveTextContent(
      error,
    );
  });

  test.each([
    { value: "a", error: "Months must be a whole number" },
    { value: "-1", error: "Months must be greater than or equal to 0" },
    { value: "12", error: "Months must be less than or equal to 11" },
    { value: "1.5", error: "Months must be a whole number" },
  ])("months input is invalid for '$value'", async ({ value, error }) => {
    const user = userEvent.setup();
    const { container } = render(mockForm);
    const dogMonthInput = screen.getByLabelText("dog-month-input", {
      selector: "input",
    });

    await user.type(dogMonthInput, value);
    expect(dogMonthInput).toBeInvalid();

    expect(container.querySelector("#dog-age-months-error")).toHaveTextContent(
      error,
    );
  });

  test("both years and months inputs are invalid", async () => {
    const user = userEvent.setup();
    const { container } = render(mockForm);
    const dogYearInput = screen.getByLabelText("dog-year-input", {
      selector: "input",
    });
    const dogMonthInput = screen.getByLabelText("dog-month-input", {
      selector: "input",
    });

    await user.type(dogYearInput, "a");
    expect(dogYearInput).toBeInvalid();

    await user.type(dogMonthInput, "21");
    expect(dogMonthInput).toBeInvalid();

    expect(container.querySelector("#dog-age-years-error")).toHaveTextContent(
      "Years must be a whole number",
    );

    expect(container.querySelector("#dog-age-months-error")).toHaveTextContent(
      "Months must be less than or equal to 11",
    );
  });
});

describe("sex of dog buttons", () => {
  test("should display text 'Is your dog male or female?'", () => {
    render(mockForm);
    expect(
      screen.getByRole("group", { name: "Is your dog male or female?" }),
    ).toBeInTheDocument();
  });

  test("should show labels for Male and Female options", () => {
    render(mockForm);
    const male_radio_button = screen.getByLabelText("Male", {
      selector: "input",
    });
    const female_radio_button = screen.getByLabelText("Female", {
      selector: "input",
    });
    expect(male_radio_button).toBeInTheDocument();
    expect(female_radio_button).toBeInTheDocument();
  });
});

describe("dog breed", () => {
  test("should render dog breed input and checkbox", () => {
    render(mockForm);
    expect(
      screen.getByPlaceholderText("Choose your Breed"),
    ).toBeInTheDocument();
    expect(screen.getByLabelText("Mixed or unknown breed")).toBeInTheDocument();
  });

  test("should display dropdown correctly when typing", async () => {
    const user = userEvent.setup();
    render(mockForm);
    const input = screen.getByLabelText("What is your dog's breed?", {
      selector: "input",
    });
    await user.type(input, "bulldog");
    expect(
      within(
        screen.getByLabelText("What is your dog's breed?", {
          selector: "ul",
        }),
      ).getAllByRole("option").length,
    ).toBe(2);
    await user.type(input, "appended text to cause no item found");
    expect(
      within(
        screen.getByLabelText("What is your dog's breed?", {
          selector: "ul",
        }),
      ).queryByRole("option"),
    ).not.toBeInTheDocument();
  });

  test("should display dropdown correctly press the dropdown arrow", async () => {
    const user = userEvent.setup();
    render(mockForm);
    const button = screen.getByLabelText("What is your dog's breed?", {
      selector: "button",
    });
    await user.click(button);
    expect(
      within(
        screen.getByLabelText("What is your dog's breed?", {
          selector: "ul",
        }),
      ).getAllByRole("option").length,
    ).toBe(11);
  });

  test("toggle mix/unknown breed checkbox", async () => {
    const user = userEvent.setup();
    render(mockForm);
    const checkbox = screen.getByText("Mixed or unknown breed");
    const input = screen.getByLabelText("What is your dog's breed?", {
      selector: "input",
    }) as HTMLInputElement;
    expect(input.value).toBe("");
    expect(input).toBeEnabled();
    await user.click(checkbox);
    expect(input.value).toBe("Mixed / Unknown");
    expect(input).toBeDisabled();
    await user.click(checkbox);
    expect(input.value).toBe("");
    expect(input).toBeEnabled();
  });
});

describe("dog sterilisation radio", () => {
  test("should display text 'Is your dog spayed or neutered?'", () => {
    render(mockForm);
    expect(
      screen.getByRole("group", { name: "Is your dog spayed or neutered?" }),
    ).toBeInTheDocument();
  });

  test("should show labels for No and Yes options", () => {
    render(mockForm);
    const no_radio_button = screen.getByLabelText("No", {
      selector: "input",
    });
    const yes_radio_button = screen.getByLabelText("Yes", {
      selector: "input",
    });
    expect(no_radio_button).toBeInTheDocument();
    expect(yes_radio_button).toBeInTheDocument();
  });

  test("verify error message displays", async () => {
    const user = userEvent.setup();
    const { container } = render(mockForm);
    expect(
      screen.getByLabelText("No", {
        selector: "input",
      }),
    ).toBeChecked();
    expect(
      screen.getByLabelText("Yes", {
        selector: "input",
      }),
    ).not.toBeChecked();
  });
});

describe("Basics page error box", () => {
  test("notification is shown when one or more fields shows an error", async () => {
    const user = userEvent.setup();
    render(mockForm);
    await user.click(screen.getByRole("button", { name: "Continue" }));
    const error = screen.getByRole("alert");
    expect(error).toBeVisible();
  });
});
