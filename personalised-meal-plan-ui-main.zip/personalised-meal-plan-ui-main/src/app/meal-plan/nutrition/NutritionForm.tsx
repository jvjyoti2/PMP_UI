import ErrorMessage from "@/app/ui/ErrorMessage";
import FieldInfoBox from "@/app/ui/FieldInfoBox";
import RadioButton from "@/app/ui/RadioButton";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import Button, { enumButtonType } from "@/app/ui/ContinueButton";
import BackButton from "@/app/ui/BackButton";
import { useAtomValue } from "jotai";
import { basicStateAtom } from "@/app/jotai/atoms";

interface FormProps {
  onBack: () => void;
  onSubmit: () => void;
}

const NutritionFormData = z.object({
  dog_eating_raw: z.enum(["no", "mixed", "yes"], {
    errorMap: () => ({
      message: "This field is required",
    }),
  }),
});

type NutritionFormData = z.infer<typeof NutritionFormData>;

export default function NutritionForm(props: FormProps) {
  const { onBack, onSubmit } = props;
  const dogName = useAtomValue(basicStateAtom).dog_name;

  const {
    register,
    watch,
    handleSubmit,
    formState: { errors },
  } = useForm<NutritionFormData>({
    mode: "all",
    resolver: zodResolver(NutritionFormData),
  });

  const dogEatingRawWatch = watch("dog_eating_raw");

  return (
    <form
      className="grid max-w-md gap-4"
      aria-label="nutrition-form"
      onSubmit={handleSubmit(onSubmit)}
    >
      <div className="items-start">
        <fieldset aria-describedby="dog-working-error">
          <legend className="font-bold">
            Is {dogName} currently eating raw?
          </legend>
          {errors.dog_eating_raw && (
            <ErrorMessage id="dog-eating-raw-error">
              {errors.dog_eating_raw.message}
            </ErrorMessage>
          )}
          <div className="mt-2">
            <FieldInfoBox summary="Understand what eating raw means and why this matters.">
              <p>
                Raw pet food is a diet for pets that includes uncooked and
                unprocessed ingredients like raw meat, bones, organs, fruits,
                vegetables, and supplements. The diet typically includes various
                meats, soft bones, organ meats, and some fruits and vegetables
                for nutrients. Some recipes also add supplements to ensure a
                balanced diet. We take into account your pet’s existing diet and
                prior experience with raw diet to formulate the meal plan. We
                recommend gradual transition with different adoption pace and
                strive to provide a balanced diet during the transition.
              </p>
            </FieldInfoBox>
          </div>
          <div className="mt-2 space-y-1">
            <div>
              <input
                type="radio"
                className="sr-only"
                id="dog-eating-raw-no"
                value="no"
                {...register("dog_eating_raw")}
              />
              <label
                htmlFor="dog-eating-raw-no"
                className="flex flex-row items-center gap-2"
              >
                <RadioButton checked={dogEatingRawWatch === "no"} />
                <span className="text-sm">Not eating raw</span>
              </label>
            </div>
            <div>
              <input
                type="radio"
                className="sr-only"
                id="dog-eating-raw-mixed"
                value="mixed"
                {...register("dog_eating_raw")}
              />
              <label
                htmlFor="dog-eating-raw-mixed"
                className="flex flex-row items-center gap-2"
              >
                <RadioButton checked={dogEatingRawWatch === "mixed"} />
                <span className="text-sm">Occasionally or mixed nutrition</span>
              </label>
            </div>
            <div>
              <input
                type="radio"
                className="sr-only"
                id="dog-eating-raw-yes"
                value="yes"
                {...register("dog_eating_raw")}
              />
              <label
                htmlFor="dog-eating-raw-yes"
                className="flex flex-row items-center gap-2"
              >
                <RadioButton checked={dogEatingRawWatch === "yes"} />
                <span className="text-sm">Yes, mostly or always raw</span>
              </label>
            </div>
          </div>
        </fieldset>
      </div>
      <div className="flex flex-col-reverse md:flex-row">
        <BackButton id="basics-back-button" type="button" onClick={onBack} />
        <Button
          id="continue-button"
          label="Continue"
          type={enumButtonType.submit}
        />
      </div>
    </form>
  );
}
