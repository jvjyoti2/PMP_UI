"use client";

import { Controller, useForm, SubmitHandler } from "react-hook-form";
import { clsx } from "clsx";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import ErrorMessage from "@/app/ui/ErrorMessage";
import ListBoxWrapper from "@/app/ui/ListBox";
import RadioButton from "@/app/ui/RadioButton";
import PetBodyCondition from "@/app/ui/PetBodyCondition";
import FieldInfoBox from "@/app/ui/FieldInfoBox";
import { useAtom, useAtomValue } from "jotai";
import { basicStateAtom, healthStateAtom } from "@/app/jotai/atoms";
import Button, { enumButtonType } from "@/app/ui/ContinueButton";
import BackButton from "@/app/ui/BackButton";
import PetActivityLevel from "@/app/ui/PetActivityLevel";

interface FormProps {
  onBack: () => void;
  onSubmit: () => void;
}

export const HealthFormData = z.object({
  dog_weight: z
    .number({
      required_error: "This field is required",
      invalid_type_error: "Weight must be a whole number",
    })
    .multipleOf(0.01, {
      message: "Weight must be a decimal number upto 2 digit",
    })
    .min(0, { message: "Weight must be greater than or equal to 1" })
    .max(1000, { message: "Weight must be less than or equal to 1000" })
    .nullable(),
  dog_expected_adult_size: z
    .string({
      required_error: "This field is required",
    })
    .min(1, { message: "This field is required" }),
  dog_body_condition: z.number(),
  dog_lose_weight: z.enum(["false", "true"], {
    errorMap: () => ({
      message: "This field is required",
    }),
  }),
  dog_activity_level: z.number(),
  dog_working: z.enum(["false", "true"], {
    errorMap: () => ({
      message: "This field is required",
    }),
  }),
});

const dogSizeList = [
  { value: "", label: "Expected adult size" },
  { value: "toy", label: "Toy (<7kg)" },
  { value: "small", label: "Small (7-15kg)" },
  { value: "medium", label: "Medium (15-27.5kg)" },
  { value: "big", label: "Big (27.5-47.5kg)" },
  { value: "giant", label: "Giant (>47.5kg)" },
];

type HealthFormData = z.infer<typeof HealthFormData>;

export default function HealthForm(props: FormProps) {
  const [healthState, setHealthState] = useAtom(healthStateAtom);
  const { onBack, onSubmit } = props;
  const dogName = useAtomValue(basicStateAtom).dog_name;

  const values = healthState;

  const {
    watch,
    register,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<HealthFormData>({
    mode: "all",
    resolver: zodResolver(HealthFormData),
    values,
  });

  const dogLoseWeightWatch = watch("dog_lose_weight");
  const dogWorkingWatch = watch("dog_working");

  const submitForm: SubmitHandler<HealthFormData> = (data) => {
    setHealthState(data);
    onSubmit();
  };

  return (
    <form
      className="grid max-w-md gap-4"
      aria-label="health-form"
      onSubmit={handleSubmit(submitForm)}
    >
      <div className="grid-column items-start">
        <label htmlFor="dog-weight" className="type-charcoal font-bold">
          How much does {dogName} weigh?
        </label>
        <div className="mt-2 flex gap-2">
          <input
            className={clsx(
              "h-12 w-11/12 rounded border border-neutral-200 bg-white px-3 focus:outline-none",

              {
                "border-primary": errors.dog_weight,
                "focus:border-neutral-500": !errors.dog_weight,
              },
            )}
            id="dog-weight"
            aria-label="dog-weight-input"
            placeholder="Weight in Kilograms"
            aria-invalid={errors.dog_weight ? "true" : "false"}
            aria-errormessage="dog-weight-error"
            {...register("dog_weight", {
              setValueAs: (val) => (val ? Number(val) : undefined),
            })}
          />
          <span className="flex w-1/12 items-center">Kg</span>
          {errors.dog_weight && (
            <ErrorMessage id="dog-weight-error">
              {errors.dog_weight.message}
            </ErrorMessage>
          )}
        </div>
      </div>

      <div className="grid-column items-start">
        <Controller
          name="dog_expected_adult_size"
          control={control}
          render={({ field: { onChange, value } }) => (
            <ListBoxWrapper
              id="dog-expected-adult-size"
              label={`What is ${dogName}'s expected adult size?`}
              value={value}
              disabled={false}
              onChange={onChange}
              options={dogSizeList}
              error={errors.dog_expected_adult_size}
            />
          )}
        />
      </div>
      <div />
      <div className="grid-column items-start">
        <Controller
          name="dog_body_condition"
          control={control}
          render={({ field: { onChange, value } }) => (
            <PetBodyCondition
              onChange={onChange}
              value={value}
              dogName={dogName}
            ></PetBodyCondition>
          )}
        ></Controller>
      </div>

      <div className="items-start">
        <fieldset aria-describedby="dog-lose-weight-error">
          <legend className="font-bold">
            Do you want {dogName} to lose weight?
          </legend>
          {errors.dog_lose_weight && (
            <ErrorMessage id="dog-lose-weight-error">
              {errors.dog_lose_weight.message}
            </ErrorMessage>
          )}

          <div className="mt-2 space-y-1">
            <div>
              <input
                type="radio"
                className="sr-only"
                id="dog-lose-weight-no"
                value="false"
                {...register("dog_lose_weight")}
              />
              <label
                htmlFor="dog-lose-weight-no"
                className="flex flex-row items-center gap-2"
              >
                <RadioButton checked={dogLoseWeightWatch === "false"} />
                <span className="text-sm">No</span>
              </label>
            </div>
            <div>
              <input
                type="radio"
                className="sr-only"
                id="dog-lose-weight-yes"
                value="true"
                {...register("dog_lose_weight")}
              />
              <label
                htmlFor="dog-lose-weight-yes"
                className="flex flex-row items-center gap-2"
              >
                <RadioButton checked={dogLoseWeightWatch === "true"} />
                <span className="text-sm">Yes</span>
              </label>
            </div>
          </div>
        </fieldset>
      </div>

      <div className="items-start">
        <fieldset aria-describedby="dog-working-error">
          <legend className="font-bold">Is {dogName} a working dog?</legend>
          {errors.dog_working && (
            <ErrorMessage id="dog-working-error">
              {errors.dog_working.message}
            </ErrorMessage>
          )}
          <div className="mt-2">
            <FieldInfoBox summary="Understand what working dog means and why this matters.">
              <p>
                A working dog is bred and trained to perform specific tasks to
                assist humans. They are intelligent and trainable and excel in
                various roles, such as service dogs for people with
                disabilities, police dogs for law enforcement, and search and
                rescue dogs for finding missing persons.
              </p>
            </FieldInfoBox>
          </div>
          <div className="mt-2 space-y-1">
            <div>
              <input
                type="radio"
                className="sr-only"
                id="dog-working-no"
                value="false"
                {...register("dog_working")}
              />
              <label
                htmlFor="dog-working-no"
                className="flex flex-row items-center gap-2"
              >
                <RadioButton checked={dogWorkingWatch === "false"} />
                <span className="text-sm">No</span>
              </label>
            </div>
            <div>
              <input
                type="radio"
                className="sr-only"
                id="dog-working-yes"
                value="true"
                {...register("dog_working")}
              />
              <label
                htmlFor="dog-working-yes"
                className="flex flex-row items-center gap-2"
              >
                <RadioButton checked={dogWorkingWatch === "true"} />
                <span className="text-sm">Yes</span>
              </label>
            </div>
          </div>
        </fieldset>
      </div>
      <div className="grid-column items-start">
        <Controller
          name="dog_activity_level"
          control={control}
          render={({ field: { onChange, value } }) => (
            <PetActivityLevel
              onChange={onChange}
              value={value}
              dogName={dogName}
            ></PetActivityLevel>
          )}
        ></Controller>
      </div>

      <div className="flex flex-col-reverse md:flex-row">
        <BackButton id="basics-back-button" type="button" onClick={onBack} />
        <Button
          id="continue-button"
          label="Continue"
          type={enumButtonType.submit}
        />
      </div>
    </form>
  );
}
