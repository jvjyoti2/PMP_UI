import { test, expect, describe, jest, afterEach } from "@jest/globals";
import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import HealthForm from "./HealthForm";
import { basicStateAtom } from "@/app/jotai/atoms";
import { mockRoutingProps } from "../../../../helpers/test_helpers";
import { TestProvider } from "../../../../helpers/test_helpers";
import { basicTestStateValues } from "../../../../helpers/test_helpers";

const HealthFormProvider = () => {
  return (
    <TestProvider initialValues={[[basicStateAtom, basicTestStateValues]]}>
      <HealthForm
        onBack={mockRoutingProps.onBack}
        onSubmit={mockRoutingProps.onSubmit}
      ></HealthForm>
    </TestProvider>
  );
};

afterEach(() => {
  jest.clearAllMocks();
});

describe("dog weight", () => {
  test("should have an input for dog weight", () => {
    render(<HealthFormProvider />);
    expect(
      screen.getByLabelText(`How much does testDogName weigh?`),
    ).toBeInTheDocument();
  });

  test("dog weight input has valid value", async () => {
    const user = userEvent.setup();
    const { container } = render(<HealthFormProvider />);
    await user.type(
      screen.getByLabelText("How much does testDogName weigh?"),
      "59",
    );
    expect(
      screen.getByLabelText("How much does testDogName weigh?"),
    ).toBeValid();

    await user.clear(screen.getByLabelText("How much does testDogName weigh?"));
    expect(
      screen.getByLabelText("How much does testDogName weigh?"),
    ).toBeInvalid();
    const error = container.querySelector("#dog-weight-error");
    expect(error).toHaveTextContent("This field is required");
  });

  test("dog weight input has invalid value", async () => {
    const user = userEvent.setup();
    const { container } = render(<HealthFormProvider />);
    await user.type(
      screen.getByLabelText("How much does testDogName weigh?"),
      "-1",
    );
    expect(
      screen.getByLabelText("How much does testDogName weigh?"),
    ).toBeInvalid();
    const error = container.querySelector("#dog-weight-error");
    expect(error).toHaveTextContent(
      "Weight must be greater than or equal to 1",
    );
  });

  test("dog weight input has invalid value", async () => {
    const user = userEvent.setup();
    const { container } = render(<HealthFormProvider />);
    await user.type(
      screen.getByLabelText("How much does testDogName weigh?"),
      "1001",
    );
    expect(
      screen.getByLabelText("How much does testDogName weigh?"),
    ).toBeInvalid();
    const error = container.querySelector("#dog-weight-error");
    expect(error).toHaveTextContent(
      "Weight must be less than or equal to 1000",
    );
  });

  test("dog weight input has error message for using special characters or letters", async () => {
    const user = userEvent.setup();
    const { container } = render(<HealthFormProvider />);
    await user.type(
      screen.getByLabelText("How much does testDogName weigh?"),
      "@475",
    );
    expect(
      screen.getByLabelText("How much does testDogName weigh?"),
    ).toBeInvalid();
    const error = container.querySelector("#dog-weight-error");
    expect(error).toHaveTextContent("Weight must be a whole number");
  });

  test("dog weight input has error message for using special characters or letters", async () => {
    const user = userEvent.setup();
    const { container } = render(<HealthFormProvider />);
    await user.type(
      screen.getByLabelText("How much does testDogName weigh?"),
      "abc",
    );
    expect(
      screen.getByLabelText("How much does testDogName weigh?"),
    ).toBeInvalid();
    const error = container.querySelector("#dog-weight-error");
    expect(error).toHaveTextContent("Weight must be a whole number");
  });
});

describe("dog expected adult size", () => {
  test("should render dog expected adult size input", () => {
    render(<HealthFormProvider />);
    expect(
      screen.getByLabelText("What is testDogName's expected adult size?"),
    ).toBeInTheDocument();
  });

  test("should display dropdown and selected item when click", async () => {
    const user = userEvent.setup();
    render(<HealthFormProvider />);
    const button = screen.getByLabelText(
      "What is testDogName's expected adult size?",
    );
    await user.click(button);
    expect(screen.getByRole("listbox")).toBeInTheDocument();
    const options = within(
      screen.getByLabelText("Expected adult size", {
        selector: "ul",
      }),
    ).getAllByRole("option");
    expect(options.length).toBe(6);
    await user.click(options[1]);
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
    expect(
      screen.getByRole("button", {
        name: /Toy/,
      }),
    ).toBeInTheDocument();
  });
});

describe("dog lose weight radio", () => {
  test("should display text 'Do you want testDogName to lose weight?'", () => {
    render(<HealthFormProvider />);
    expect(
      screen.getByRole("group", {
        name: "Do you want testDogName to lose weight?",
      }),
    ).toBeInTheDocument();
  });

  test("should show labels for No and Yes options", () => {
    render(<HealthFormProvider />);
    const dogLoseWeight = screen.getByRole("group", {
      name: "Do you want testDogName to lose weight?",
    });
    const no_radio_button = within(dogLoseWeight).getByLabelText("No", {
      selector: "input",
    });
    const yes_radio_button = within(dogLoseWeight).getByLabelText("Yes", {
      selector: "input",
    });
    expect(no_radio_button).toBeInTheDocument();
    expect(yes_radio_button).toBeInTheDocument();
  });

  test("verify error message displays", async () => {
    const user = userEvent.setup();
    render(<HealthFormProvider />);
    const dogLoseWeight = screen.getByRole("group", {
      name: "Do you want testDogName to lose weight?",
    });
    expect(
      within(dogLoseWeight).getByLabelText("No", {
        selector: "input",
      }),
    ).toBeChecked();
    expect(
      within(dogLoseWeight).getByLabelText("Yes", {
        selector: "input",
      }),
    ).not.toBeChecked();
  });
});

describe("dog body condition", () => {
  test("should display text 'Choose testDogName body condition'", () => {
    render(<HealthFormProvider />);
    expect(
      screen.getByLabelText("Choose testDogName's body condition"),
    ).toBeInTheDocument();
  });
});

describe("dog working radio", () => {
  test("should show labels for No and Yes options", () => {
    render(<HealthFormProvider />);
    const dogWorking = screen.getByRole("group", {
      name: /^Is [a-z]* a working dog\?$/i,
    });
    const working_no_radio_button = within(dogWorking).getByLabelText("No", {
      selector: "input",
    });
    const working_yes_radio_button = within(dogWorking).getByLabelText("Yes", {
      selector: "input",
    });
    expect(working_no_radio_button).toBeInTheDocument();
    expect(working_yes_radio_button).toBeInTheDocument();
  });

  test("verify error message displays", async () => {
    const user = userEvent.setup();
    const { container } = render(<HealthFormProvider />);
    const dogWorking = screen.getByRole("group", {
      name: /^Is [a-z]* a working dog\?$/i,
    });
    expect(
      within(dogWorking).getByLabelText("No", {
        selector: "input",
      }),
    ).toBeChecked();
    expect(
      within(dogWorking).getByLabelText("Yes", {
        selector: "input",
      }),
    ).not.toBeChecked();
  });
});

describe("dog activity level", () => {
  test("should display text 'Describe testDogName activity level'", () => {
    render(<HealthFormProvider />);
    expect(
      screen.getByLabelText("Describe testDogName's activity level"),
    ).toBeInTheDocument();
  });
});
