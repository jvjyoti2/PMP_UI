import { test, expect } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import AndWordmark from "./AndWordmark";

test("label", () => {
  render(<AndWordmark />);

  expect(screen.getByLabelText("AND")).toBeInTheDocument();
});

test("custom props", () => {
  render(<AndWordmark data-testid="123" />);

  expect(screen.getByTestId("123")).toBeInTheDocument();
});
