import { test, expect } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import ProgressBar from "./ProgressBar";

test("render all 4 list items with health selected", () => {
  render(<ProgressBar focusPage={"health"} />);

  expect(screen.getByLabelText("Meal plan progress")).toBeInTheDocument();
  expect(screen.getAllByRole("listitem")).toHaveLength(4);
  expect(screen.getAllByRole("listitem")[1].getAttribute("aria-current")).toBe(
    "step",
  );
});
