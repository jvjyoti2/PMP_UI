"use client";

import HeadingMain from "@/app/ui/HeadingMain";
import { basicStateAtom } from "@/app/jotai/atoms";
import { useAtomValue } from "jotai";

export default function MealPlanDietReport() {
  const dogName = useAtomValue(basicStateAtom).dog_name;

  return (
    <>
      <div className="bg-neutral-100 px-2 pb-4 pt-12"></div>
      <main className="grid justify-center px-4 py-6">
        <HeadingMain>Diet Report for {dogName}</HeadingMain>
        <div className="mt-4 justify-between gap-2 md:mt-8"></div>
      </main>
    </>
  );
}
