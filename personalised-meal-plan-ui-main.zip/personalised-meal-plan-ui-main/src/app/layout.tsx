import type { Metadata } from "next";
import { Poppins, Roboto } from "next/font/google";
import "./globals.css";

/**
 * See https://drive.google.com/file/d/1XZKTXLvT25vmL96LThbCVgFfDyMMLSAF/view.
 * Page 21 Everyday fonts.
 * See also https://nextjs.org/docs/app/building-your-application/optimizing/fonts#with-tailwind-css.
 */
const poppins = Poppins({
  weight: ["400", "500", "600"],
  style: ["normal", "italic"],
  subsets: ["latin"],
  variable: "--font-poppins",
  display: "swap",
});

const roboto = Roboto({
  weight: ["400", "700"],
  style: ["normal", "italic"],
  subsets: ["latin"],
  variable: "--font-roboto",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Personalised Meal Plan",
  description: "An AND Somerville Project",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${poppins.variable} ${roboto.variable} h-full`}>
      <body className="text-neutral grid min-h-full">
        <div>{children}</div>
      </body>
    </html>
  );
}
