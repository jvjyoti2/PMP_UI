export enum enumButtonType {
  submit,
}

export default function Button({
  id = "",
  label = "",
}: Readonly<{
  id: string;
  label: string;
  type: enumButtonType;
}>) {
  return (
    <button
      id={id}
      className="h-11 w-full rounded bg-primary uppercase text-white hover:bg-hover"
    >
      {label}
    </button>
  );
}
