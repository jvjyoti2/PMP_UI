import { Fragment, useState } from "react";
import { Listbox, Transition } from "@headlessui/react";
import { FieldError } from "react-hook-form";
import ErrorMessage from "./ErrorMessage";
import { clsx } from "clsx";
import ArrowDownIcon from "./ArrowDownIcon";

export default function ListBoxWrapper({
  id = "",
  label = "",
  value = "",
  disabled = false,
  onChange,
  options,
  error,
}: {
  id: string;
  label: string;
  value: string;
  disabled: boolean;
  onChange: any;
  options: {
    value: string;
    label: string;
  }[];
  error: FieldError | undefined;
}) {
  const getNameFromValue = (value: string) => {
    const option = options.find((option) => option.value === value);
    return option ? option.label : "";
  };

  return (
    <>
      <Listbox value={value} onChange={onChange} disabled={disabled}>
        {({ open }) => (
          <>
            <Listbox.Label className="type-charcoal font-bold">
              {label}
            </Listbox.Label>
            <div className="relative mt-2">
              <Listbox.Button
                className={clsx(
                  "mb-px h-12 w-full border border-neutral-200 px-3 text-left focus:outline-none",
                  {
                    "rounded-t-lg": open,
                    rounded: !open,
                    "border-primary": error?.type,
                    "focus:border-neutral-500": !error?.type,
                    "text-neutral-300": value === "",
                  },
                )}
              >
                {getNameFromValue(value)}
                <div className="absolute inset-y-0 right-0 flex items-center pr-2">
                  <ArrowDownIcon size={20} />
                </div>
              </Listbox.Button>
            </div>
            <Transition
              as={Fragment}
              leave="transition ease-in duration-100"
              leaveFrom="opacity-100"
              leaveTo="opacity-0"
            >
              <Listbox.Options className="ring-opacity-9 max-h-60 w-full overflow-auto rounded-b-lg border border-neutral-200">
                {options.map((option) => (
                  <Listbox.Option
                    key={option.value}
                    className={({ selected, active }) => {
                      return clsx(
                        "text-black relative cursor-default px-4 py-2",
                        {
                          "bg-neutral-100": active || selected,
                        },
                      );
                    }}
                    value={option.value}
                  >
                    {({ selected }) => (
                      <>
                        <span className="block truncate">{option.label}</span>
                        {selected ? (
                          <span
                            className={clsx(
                              "absolute inset-y-0 left-0 flex items-center pl-3",
                            )}
                          ></span>
                        ) : null}
                      </>
                    )}
                  </Listbox.Option>
                ))}
              </Listbox.Options>
            </Transition>
          </>
        )}
      </Listbox>
      {error && <ErrorMessage id={`${id}-error`}>{error.message}</ErrorMessage>}
    </>
  );
}
