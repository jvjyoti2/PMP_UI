interface ErrorMessageProps {
  children?: React.ReactNode;
  id: string;
}

export default function ErrorMessage(props: ErrorMessageProps) {
  return (
    <p id={props.id} aria-live="polite" className="mt-1 text-primary">
      {props.children}
    </p>
  );
}
