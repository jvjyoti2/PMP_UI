import React from "react";
import { Slider } from "rsuite";
import "rsuite/dist/rsuite-no-reset.css";
import { clsx } from "clsx";
import DogSizeIcon from "./DogSizeIcon";

export const conditions = [
  {
    label: "Underweight",
    value: "underweight",
    description: "On the thin side.",
  },
  {
    label: "On the skinny side",
    value: "skinny",
    description: "Bones raised with minimal tissue between the skin and bone.",
  },
  {
    label: "Ideal",
    value: "ideal",
    description: "Ribs can be felt through a slight fat cover.",
  },
  {
    label: "On the chubby side",
    value: "chubby",
    description: "Difficult to feel ribs through moderate fat cover.",
  },
  {
    label: "Overweight",
    value: "overweight",
    description: "Ribs are difficult to feel under thick fat.",
  },
];

interface PetBodyConditionProps {
  onChange: (value: number) => void;
  value: number;
  dogName: string;
}

const PetBodyCondition = (props: PetBodyConditionProps) => {
  const { onChange, value = 0, dogName } = props;
  return (
    <>
      <label htmlFor="dog-weight" className="type-charcoal font-bold">
        Choose {dogName}&apos;s body condition
      </label>
      <div className="mt-2 flex justify-between">
        {conditions.map((condition, index) => (
          <DogSizeIcon
            condition={condition.value}
            key={index}
            selected={index === value}
          />
        ))}
      </div>
      <Slider
        min={0}
        max={conditions.length - 1}
        value={value}
        className="mx-6 mt-4"
        graduated
        tooltip={true}
        renderTooltip={(value) => {
          if (value !== undefined) {
            const label = conditions[value].value;
            return (
              <span>{label.charAt(0).toUpperCase() + label.slice(1)}</span>
            );
          }
          return null;
        }}
        onChange={onChange}
      />
      <div
        className={clsx(
          "h-18 mt-6 w-full rounded border border-neutral-200 bg-white px-8 py-4 focus:outline-none",
        )}
      >
        <p className="type-charcoal font-bold">{conditions[value].label}</p>
        <p className="mt-2 text-sm">{conditions[value].description}</p>
      </div>
    </>
  );
};

export default PetBodyCondition;
