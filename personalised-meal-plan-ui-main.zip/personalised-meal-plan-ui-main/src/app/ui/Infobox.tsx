import InfoIcon from "./InfoIcon";

interface InfoboxProps {
  children?: React.ReactNode;
}

export default function Infobox(props: InfoboxProps) {
  return (
    <div className="flex gap-4 hyphens-auto rounded bg-blue/10 p-4">
      <InfoIcon />
      <>{props.children}</>
    </div>
  );
}
