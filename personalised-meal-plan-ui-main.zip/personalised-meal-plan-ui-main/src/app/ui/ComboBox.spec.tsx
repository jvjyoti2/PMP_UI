import { test, expect } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import ComboBoxWrapper from "@/app/ui/ComboBox";
import userEvent from "@testing-library/user-event";

test("rendered correctly", async () => {
  const mockOnChange = () => {};
  const mockOnBlur = () => {};
  const options = [
    { label: "Option 1", value: "1" },
    { label: "Option 2", value: "2" },
  ];
  render(
    <ComboBoxWrapper
      id="my-combobox"
      placeholder="Select something"
      label="Select a list item"
      value="Option 2"
      disabled={false}
      onChange={mockOnChange}
      onBlur={mockOnBlur}
      options={options}
      error={undefined}
    />,
  );

  const inputElement = screen.getByLabelText("Select a list item", {
    selector: "input",
  });
  expect(inputElement).toBeInTheDocument();
  expect(screen.queryByRole("listbox")).toBeNull();

  const user = userEvent.setup();
  await user.click(screen.getByRole("button"));
  expect(screen.getByRole("listbox")).toBeInTheDocument();
});
