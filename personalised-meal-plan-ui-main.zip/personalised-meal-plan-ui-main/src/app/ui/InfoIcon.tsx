interface Props {
  label?: string;
  colour?: string;
}
const InfoIcon = (props: Props) => {
  const { label = "Information", colour = "currentColor" } = props;
  return (
    <svg
      role="img"
      aria-label={label}
      fill={colour}
      viewBox="0 0 20 20"
      className="size-6 shrink-0 text-blue"
    >
      <path d="M10 1.4a8.6 8.6 0 1 0 0 17.2 8.6 8.6 0 0 0 0-17.2ZM0 10a10 10 0 1 1 20 0 10 10 0 0 1-20 0ZM10 9.3c.4 0 .7.3.7.7v5a.7.7 0 1 1-1.4 0v-5c0-.4.3-.7.7-.7ZM8.6 6.4a1.4 1.4 0 1 1 2.8 0 1.4 1.4 0 0 1-2.8 0Z" />
    </svg>
  );
};

export default InfoIcon;
