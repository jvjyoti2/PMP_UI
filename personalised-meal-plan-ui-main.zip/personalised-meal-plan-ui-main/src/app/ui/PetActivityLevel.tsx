import React from "react";
import { Slider } from "rsuite";
import "rsuite/dist/rsuite-no-reset.css";
import { clsx } from "clsx";
import DogActivitySizeIcon from "./DogActivitySizeIcon";

export const activities = [
  {
    label: "Leisurely",
    value: "leisurely",
    description:
      "Less than 45 minutes of exercise a day. Spends most of the day lying around with only short walks.",
  },
  {
    label: "Moderately Active",
    value: "moderatelyActive",
    description: "One hour walk per day + extra play on weekends.",
  },
  {
    label: "Active",
    value: "active",
    description:
      "Several hours of exercise a day (includes regular hikes, runs, and extended play sessions).",
  },
  {
    label: "Very Active",
    value: "veryActive",
    description: "Several hours of high-intensity activity a day.",
  },
];

interface PetActivityLevelProps {
  onChange: (value: number) => void;
  value: number;
  dogName: string;
}

const PetActivityLevel = (props: PetActivityLevelProps) => {
  const { onChange, value = 0, dogName } = props;

  return (
    <>
      <label htmlFor="dog-weight" className="type-charcoal font-bold">
        Describe {dogName}&apos;s activity level
      </label>
      <div className="mt-2 flex justify-between">
        {activities.map((activity, index) => (
          <DogActivitySizeIcon
            activity={activity.value}
            key={index}
            selected={index === value}
          />
        ))}
      </div>
      <Slider
        min={0}
        max={activities.length - 1}
        value={value}
        className="mx-6 mt-4"
        graduated
        tooltip={true}
        renderTooltip={(value) => {
          if (value !== undefined) {
            const label = activities[value].value;
            return (
              <span>{label.charAt(0).toUpperCase() + label.slice(1)}</span>
            );
          }
          return null;
        }}
        onChange={onChange}
      />
      <div
        className={clsx(
          "mt-6 h-28 w-full overflow-y-auto rounded border border-neutral-200 bg-white px-8 py-4 ",
        )}
      >
        <p className="type-charcoal font-bold">{activities[value].label}</p>
        <p className="mt-2 text-sm">{activities[value].description}</p>
      </div>
    </>
  );
};

export default PetActivityLevel;
