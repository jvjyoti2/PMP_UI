import { Disclosure } from "@headlessui/react";
import InfoIcon from "./InfoIcon";
import ArrowDownIcon from "./ArrowDownIcon";
import clsx from "clsx";

interface FieldInfoBoxProps {
  summary: string;
  children: React.ReactNode;
}
const FieldInfoBox = (props: FieldInfoBoxProps) => {
  const { summary, children } = props;
  return (
    <Disclosure>
      {({ open }) => (
        <>
          <Disclosure.Button className="w-full">
            <div
              className={clsx("flex gap-4 bg-blue/10 p-4 ", {
                "rounded-t": open,
                rounded: !open,
              })}
            >
              <InfoIcon />
              <p className="grow hyphens-auto text-left">{summary}</p>
              <ArrowDownIcon
                size={24}
                className={clsx(
                  "rotate transform justify-items-end transition-all",
                  {
                    "rotate-180": open,
                  },
                )}
                label={open ? "collapse" : "expand"}
              />
            </div>
          </Disclosure.Button>
          <Disclosure.Panel className="rounded-b bg-neutral-50 p-4">
            <div className="h-32 overflow-y-auto [&>*]:mb-2">{children}</div>
          </Disclosure.Panel>
        </>
      )}
    </Disclosure>
  );
};

export default FieldInfoBox;
