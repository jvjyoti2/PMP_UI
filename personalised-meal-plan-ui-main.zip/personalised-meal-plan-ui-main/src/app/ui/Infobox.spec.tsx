import { test, expect } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import Infobox from "./Infobox";

test("icon", () => {
  render(<Infobox />);

  expect(screen.getByRole("img", { name: "Information" })).toBeInTheDocument();
});

test("children", () => {
  render(
    <Infobox>
      <p>Some informative text.</p>
    </Infobox>,
  );

  expect(screen.getByText("Some informative text.")).toBeInTheDocument();
});
