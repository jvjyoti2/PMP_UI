import { test, expect } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import HeadingMain from "./HeadingMain";

test("h1 rendered", () => {
  render(<HeadingMain>My heading</HeadingMain>);

  expect(screen.getByRole("heading", { level: 1 })).toHaveTextContent(
    "My heading",
  );
});
