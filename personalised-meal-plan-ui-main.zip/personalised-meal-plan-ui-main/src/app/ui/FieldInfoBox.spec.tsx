import { test, expect, describe } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import FieldInfoBox from "./FieldInfoBox";
import userEvent from "@testing-library/user-event";

describe("FieldInfoBox", () => {
  test("has information icon", () => {
    render(<FieldInfoBox summary="summary">content</FieldInfoBox>);

    expect(
      screen.getByRole("img", { name: "Information" }),
    ).toBeInTheDocument();
  });

  test("summary title is shown", () => {
    render(<FieldInfoBox summary="This is the summary">content</FieldInfoBox>);

    expect(screen.getByText("This is the summary")).toBeInTheDocument();
  });

  test("does not render children by default", () => {
    render(<FieldInfoBox summary="summary">content</FieldInfoBox>);

    expect(screen.queryByText("content")).not.toBeInTheDocument();
  });

  test("displays content when expanded", async () => {
    render(<FieldInfoBox summary="summary">content</FieldInfoBox>);

    const user = userEvent.setup();
    await user.click(screen.getByRole("button"));
    expect(screen.getByText("content")).toBeInTheDocument();
  });

  test("hides content when collapsed after being expanded", async () => {
    render(<FieldInfoBox summary="summary">content</FieldInfoBox>);

    const user = userEvent.setup();
    await user.click(screen.getByRole("button")); //expand
    await user.click(screen.getByRole("button")); // collpase
    expect(screen.queryByText("content")).not.toBeInTheDocument();
  });
});
