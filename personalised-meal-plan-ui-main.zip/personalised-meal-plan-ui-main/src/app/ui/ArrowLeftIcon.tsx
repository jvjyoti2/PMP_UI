const ArrowLeftIcon = ({ size = 16 }: { size?: number }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 16 16"
      fill="none"
    >
      <path
        fill="#D82036"
        stroke="#D82036"
        d="M1.1 7.43h.02v.01l6.14 5.47c.25.18.59.12.73-.07.22-.3.15-.57-.01-.69h-.02l-.01-.02-5.43-4.77-.02-.01v-.01a.62.62 0 0 1-.2-.44.8.8 0 0 1 .1-.36l.04-.09.08-.06 5.43-4.77c.24-.22.26-.51.06-.74-.2-.24-.5-.26-.72-.07h-.01v.01h-.01v.01h-.01v.01h-.01v.01l-.02.01v.01L1.07 6.3a.96.96 0 0 0-.23.58c0 .24.1.43.26.56Z"
      />
    </svg>
  );
};

export default ArrowLeftIcon;
