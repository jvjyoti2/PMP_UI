interface HeadingMainProps {
  children?: React.ReactNode;
}

export default function HeadingMain(props: HeadingMainProps) {
  return (
    <h1 className="font-display text-2xl font-bold uppercase leading-9 text-primary">
      {props.children}
    </h1>
  );
}
