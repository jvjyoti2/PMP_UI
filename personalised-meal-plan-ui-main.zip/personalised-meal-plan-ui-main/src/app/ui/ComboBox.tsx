import { Fragment, useState } from "react";
import { Combobox, Transition } from "@headlessui/react";
import { FieldError } from "react-hook-form";
import ErrorMessage from "./ErrorMessage";
import { clsx } from "clsx";
import ArrowDownIcon from "./ArrowDownIcon";

export default function ComboBoxWrapper({
  id = "",
  placeholder = "",
  label = "",
  value = "",
  disabled = false,
  onChange,
  onBlur,
  options,
  error,
}: {
  id: string;
  placeholder: string;
  label: string;
  value: string;
  disabled: boolean;
  onChange: any;
  onBlur: any;
  options: {
    value: string;
    label: string;
  }[];
  error: FieldError | undefined;
}) {
  const [query, setQuery] = useState("");

  const filteredOptions =
    query === ""
      ? options
      : options.filter((option) => {
          return option.label.toLowerCase().includes(query.toLowerCase());
        });

  const getNameFromValue = (value: string) => {
    const option = options.find((option) => option.value === value);
    return option ? option.label : value;
  };

  return (
    <>
      <Combobox value={value} onChange={onChange} disabled={disabled}>
        {({ open }) => (
          <>
            <Combobox.Label className="type-charcoal font-bold">
              {label}
            </Combobox.Label>
            {error && (
              <ErrorMessage id={`${id}-error`}>{error.message}</ErrorMessage>
            )}
            <div className="relative mt-2">
              <Combobox.Input
                className={clsx(
                  "mb-px h-12 w-full border border-neutral-200 px-3 focus:outline-none",
                  {
                    "rounded-t-lg": open,
                    rounded: !open,
                    "border-primary": error?.type,
                    "focus:border-neutral-500": !error?.type,
                  },
                )}
                id={id}
                type="text"
                onChange={(event) => setQuery(event.target.value)}
                displayValue={(optionValue: string) =>
                  getNameFromValue(optionValue)
                }
                onBlur={onBlur}
                placeholder={placeholder}
              />
              <Combobox.Button className="absolute inset-y-0 right-0 flex items-center pr-2">
                <ArrowDownIcon size={20} />
              </Combobox.Button>
            </div>
            <Transition
              as={Fragment}
              leave="transition ease-in duration-100"
              leaveFrom="opacity-100"
              leaveTo="opacity-0"
              afterLeave={() => setQuery("")}
            >
              <Combobox.Options className="ring-opacity-9 max-h-60 w-full overflow-auto rounded-b-lg border border-neutral-200">
                {filteredOptions.length === 0 && query !== "" ? (
                  <div className="text-gray-700 relative cursor-default select-none px-4 py-2">
                    Nothing found.
                  </div>
                ) : (
                  filteredOptions.map((option) => (
                    <Combobox.Option
                      key={option.value}
                      className={({ active }) =>
                        `text-black relative cursor-default px-4 py-2 ${
                          active ? "bg-neutral-100" : "bg-white"
                        }`
                      }
                      value={option.value}
                    >
                      {({ selected, active }) => (
                        <>
                          <span
                            className={`block truncate ${
                              selected ? "font-medium" : "font-normal"
                            }`}
                          >
                            {option.label}
                          </span>
                          {selected ? (
                            <span
                              className={`absolute inset-y-0 left-0 flex items-center pl-3 ${
                                active ? "text-white" : "text-orange-600"
                              }`}
                            ></span>
                          ) : null}
                        </>
                      )}
                    </Combobox.Option>
                  ))
                )}
              </Combobox.Options>
            </Transition>
          </>
        )}
      </Combobox>
    </>
  );
}
