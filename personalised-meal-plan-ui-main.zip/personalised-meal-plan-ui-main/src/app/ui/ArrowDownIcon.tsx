interface ArrowDownIconProps {
  size?: number;
  className?: string;
  label?: string;
}

const ArrowDownIcon = (props: ArrowDownIconProps) => {
  const { size, className, label } = props;
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 12 12"
      fill="none"
      aria-label={label}
      role="img"
      className={className}
    >
      <path
        fill="#323232"
        d="M5.983 9.223a.888.888 0 0 1-.707-.333L1.16 4.275c-.25-.332-.208-.831.125-1.08.333-.25.79-.25 1.04.083L5.9 7.352c.041.041.083.041.166 0l3.575-4.074c.291-.333.749-.374 1.081-.083.333.29.374.748.083 1.08l-.041.042L6.69 8.932a1.085 1.085 0 0 1-.707.29Z"
      />
    </svg>
  );
};

export default ArrowDownIcon;
