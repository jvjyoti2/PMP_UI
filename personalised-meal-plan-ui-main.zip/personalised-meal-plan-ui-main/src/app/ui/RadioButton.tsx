const RadioButton = (props: RadioButtonProps) => {
  const checkedSVG = (
    <circle fill="#D82036" stroke="#D82036" cx="8" cy="8" r="4" />
  );

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 16 16"
    >
      <circle fill="#FFFFFF" stroke="#D82036" cx="8" cy="8" r="7" />
      {props.checked && checkedSVG}
    </svg>
  );
};

type RadioButtonProps = {
  checked?: boolean;
};

export default RadioButton;
