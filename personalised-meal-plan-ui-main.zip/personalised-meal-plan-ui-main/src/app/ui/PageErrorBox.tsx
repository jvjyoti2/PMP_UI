interface PageErrorBoxProps {
  children?: React.ReactNode;
}

export default function PageErrorBox(props: PageErrorBoxProps) {
  return (
    <div
      className="flex gap-4 hyphens-auto rounded bg-primary/10 p-4"
      role="alert"
    >
      <svg
        role="img"
        aria-label="Page Error"
        fill="currentColor"
        viewBox="0 0 20 20"
        className="size-6 shrink-0 text-primary"
      >
        <path d="M13.53 6.47c.28.28.28.73 0 1l-6.05 6.06a.71.71 0 1 1-1.01-1l6.05-6.06a.71.71 0 0 1 1.01 0Z" />
        <path d="M6.47 6.47a.71.71 0 0 1 1 0l6.06 6.05a.71.71 0 1 1-1 1.01L6.46 7.48a.71.71 0 0 1 0-1.01Z" />
        <path d="M10 1.43a8.57 8.57 0 1 0 0 17.14 8.57 8.57 0 0 0 0-17.14ZM0 10a10 10 0 1 1 20 0 10 10 0 0 1-20 0Z" />
      </svg>

      <>{props.children}</>
    </div>
  );
}
