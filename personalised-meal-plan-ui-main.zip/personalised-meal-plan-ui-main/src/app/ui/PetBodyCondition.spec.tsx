import { test, expect, describe, jest } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import PetBodyCondition, { conditions } from "./PetBodyCondition";

describe("PetBodyCondition", () => {
  test("should render DogSizeIcon for each condition", () => {
    render(<PetBodyCondition onChange={jest.fn()} value={0} />);
    const dogSizeIcons = screen.getAllByRole("img");
    expect(dogSizeIcons.length).toBe(conditions.length);
  });

  test("should show the default DogSizeIcon, title and description", () => {
    render(<PetBodyCondition onChange={jest.fn()} value={0} />);
    expect(
      screen.getByText(conditions[0].label, { selector: "p" }),
    ).toBeInTheDocument();
    expect(screen.getByRole("img", { current: true })).toHaveTextContent(
      conditions[0].label,
    );
  });

  test("should update icon and description when Slider is set to different value", async () => {
    const value = 1;
    render(<PetBodyCondition onChange={jest.fn()} value={value} />);
    expect(
      screen.getByText(conditions[value].label, { selector: "p" }),
    ).toBeInTheDocument();
    expect(
      screen.getByText(conditions[value].description, { selector: "p" }),
    ).toBeInTheDocument();
    expect(screen.getByRole("img", { current: true })).toHaveTextContent(
      conditions[value].label,
    );
  });
});
