import { test, expect } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import ListBoxWrapper from "@/app/ui/ListBox";
import userEvent from "@testing-library/user-event";

test("rendered correctly", async () => {
  const mockOnChange = () => {};
  const options = [
    { label: "Please select one", value: "" },
    { label: "Option 1", value: "1" },
    { label: "Option 2", value: "2" },
  ];
  render(
    <ListBoxWrapper
      id="my-combobox"
      label="Select a list item"
      value="Option 2"
      disabled={false}
      onChange={mockOnChange}
      options={options}
      error={undefined}
    />,
  );

  const button = screen.getByRole("button");
  expect(button).toBeInTheDocument();
  expect(screen.queryByRole("listbox")).toBeNull();

  const user = userEvent.setup();
  await user.click(button);
  expect(screen.getByRole("listbox")).toBeInTheDocument();
});
