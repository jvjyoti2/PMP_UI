"use client";

import ArrowLeftIcon from "./ArrowLeftIcon";

export default function BackButton({
  id = "",
  onClick,
}: {
  id: string;
  onClick: any;
  type: string;
}) {
  return (
    <button
      id={id}
      onClick={onClick}
      className="flex h-11 w-full flex-row place-content-center items-center gap-2"
    >
      <ArrowLeftIcon size={16} />
      <label htmlFor={id} className="font-bold uppercase text-primary">
        Back
      </label>
    </button>
  );
}
