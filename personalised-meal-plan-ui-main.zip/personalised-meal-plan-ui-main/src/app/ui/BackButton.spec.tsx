import { describe, test, expect, jest } from "@jest/globals";
import { fireEvent, render, screen } from "@testing-library/react";
import BackButton from "./BackButton";

describe("button", () => {
  test("renders correctly", async () => {
    const mockBack = jest.fn();
    render(<BackButton id="back-button" onClick={mockBack} type="button" />);

    const buttonElement = screen.getByRole("button");
    expect(buttonElement).toBeInTheDocument();

    fireEvent.click(buttonElement);
    expect(mockBack).toHaveBeenCalledTimes(1);
  });
});
