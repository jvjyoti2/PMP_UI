import { test, expect } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import ErrorMessage from "./ErrorMessage";

test("error rendered", () => {
  render(<ErrorMessage id="test-error">My error</ErrorMessage>);

  const container = screen.getByText("My error");
  expect(container).toBeInTheDocument();
  expect(container.getAttribute("id")).toBe("test-error");
});
