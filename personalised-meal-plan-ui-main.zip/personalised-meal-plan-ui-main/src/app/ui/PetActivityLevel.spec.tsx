import React from "react";
import { jest, test, expect, describe } from "@jest/globals";
import { fireEvent, render, screen } from "@testing-library/react";
import PetActivityLevel, { activities } from "./PetActivityLevel";

describe("PetActivityLevel", () => {
  test("should render DogActivitySizeIcon for each condition", () => {
    render(
      <PetActivityLevel onChange={jest.fn()} value={0} dogName="mockDogName" />,
    );
    const dogSizeIcons = screen.getAllByRole("img");
    expect(dogSizeIcons.length).toBe(activities.length);
  });

  test("should show the default DogActivitySizeIcon, title and description", () => {
    render(
      <PetActivityLevel onChange={jest.fn()} value={0} dogName="mockDogName" />,
    );
    expect(
      screen.getByText(activities[0].label, { selector: "p" }),
    ).toBeInTheDocument();
    expect(screen.getByRole("img", { current: true })).toHaveTextContent(
      activities[0].label,
    );
  });

  test("should update icon and description when Slider is set to different value", async () => {
    const value = 1;
    render(
      <PetActivityLevel
        onChange={jest.fn()}
        value={value}
        dogName="mockDogName"
      />,
    );
    expect(
      screen.getByText(activities[value].label, { selector: "p" }),
    ).toBeInTheDocument();
    expect(
      screen.getByText(activities[value].description, { selector: "p" }),
    ).toBeInTheDocument();
    expect(screen.getByRole("img", { current: true })).toHaveTextContent(
      activities[value].label,
    );
  });

  test("should pass index to onChange when slider moved", async () => {
    const mockFn = jest.fn();
    const { container } = render(
      <PetActivityLevel onChange={mockFn} value={0} dogName="mockDogName" />,
    );
    const handle = container.querySelector(".rs-slider-handle") as HTMLElement;
    fireEvent.keyDown(handle, { key: "ArrowUp" });
    expect(mockFn.mock.calls[0][0]).toBe(1);
  });
});
