import { describe, test, expect } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import Button, { enumButtonType } from "./ContinueButton";

describe("button", () => {
  test("renders correctly", async () => {
    render(
      <Button
        id="large-button"
        label="Continue"
        type={enumButtonType.submit}
      />,
    );

    const buttonElement = screen.getByRole("button");
    expect(buttonElement).toBeInTheDocument();
  });
});
