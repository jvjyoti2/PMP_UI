import { test, expect } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import PageErrorBox from "./PageErrorBox";

test("icon", () => {
  render(<PageErrorBox />);

  expect(screen.getByRole("alert")).toBeInTheDocument();
});

test("children", () => {
  render(
    <PageErrorBox>
      <p>Some warning text.</p>
    </PageErrorBox>,
  );

  expect(screen.getByText("Some warning text.")).toBeInTheDocument();
});
