# Personalised Meal Plan

## Prerequisites

Follow [Basic Developer Machine Setup](https://anddigitaltransformation.atlassian.net/wiki/spaces/SOM/pages/4562550823/Basic+Developer+Machine+Setup) and [Setup for JavaScript Development](https://anddigitaltransformation.atlassian.net/wiki/spaces/SOM/pages/4606558774/Setup+for+JavaScript+Development). Ensure that you have a recent version of Node.js installed by running

```bash
node --version
```

## Getting Started

First, after cloning the repo, install the dependencies:

```bash
npm install
```

## Running the code

Run the development server:

```bash
npm run dev
```

Run Jest in watch mode:

```bash
npx jest --watch
```

Start the [Playwright](https://playwright.dev/docs/intro) integration tests in [UI mode](https://playwright.dev/docs/test-ui-mode) to facilitate test-driven development. Ensure that the development server is running first.

```bash
npx playwright test --ui
```

## Framework

This project uses [NextJS](https://nextjs.org/docs) and the App Router pattern. This is a highly opinionated pattern where the [folder structure matters](https://nextjs.org/docs/app/building-your-application/routing) for routing.

[This tutorial](https://nextjs.org/learn/dashboard-app) gives a good introduction to NextJS App Router, and is recommended if you're new to NextJS.

## Styling

This project uses [TailwindCSS](https://tailwindcss.com/docs/installation) as a styling system. Tailwind provides extendable CSS utility classes and keeps styling close to the components it impacts.

### Fonts

Given this is a NextJS project we use the [NextJS font optimisation](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) pattern. You can see an example of how this is used in `/src/app/layout.tsx`, where the Roboto Google font is applied as the default. Notice it supplies a custom CSS class. This can be combined with Tailwind using string interpolation.

https://nextjs.org/docs/app/building-your-application/configuring/eslint#linting-custom-directories-and-files

## Linting, Testing & Pre-commit Hooks

The config of this project ties together linting, testing and pre-commit hooks. These have been setup so that they work together to ensure consistent, bug-free code (not that we would ever introduce bugs anyway). The project uses [trunk-based development](https://trunkbaseddevelopment.com/) so this setup is important to ensure that new code doesn't break the pipeline or cause havoc for other devs.

The linting for this project occurs on saving a file, running a script manually, and committing code.

The [pre-commit hooks](.husky/pre-commit) carry out linting and testing when a commit is created or amended. Commands can be added/edited here to change the behaviour of these.

## Testing

This section will define a consistent test approach to be used in this project across the team.

TODO define what types of testing occur where, styleguide as to how to create tests, how to structure, organise, name and arrange test files.
