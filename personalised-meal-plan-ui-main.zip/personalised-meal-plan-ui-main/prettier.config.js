/** @type {import("prettier").Config} */
const tailwindConfig = {
  plugins: ["prettier-plugin-tailwindcss"],
};

export default tailwindConfig;
