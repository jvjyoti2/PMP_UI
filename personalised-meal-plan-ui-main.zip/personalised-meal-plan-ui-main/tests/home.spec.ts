import { test, expect } from "@playwright/test";

test.beforeEach(async ({ page }) => {
  await page.goto("/");
});

test("has title", async ({ page }) => {
  await expect(page).toHaveTitle("Personalised Meal Plan");
});

test("has heading", async ({ page }) => {
  await expect(
    page.getByRole("heading", { name: "Personalised Meal Plan" }),
  ).toBeVisible();
});

test("has link", async ({ page }) => {
  await expect(page.getByRole("link", { name: "Get started" })).toBeVisible();
});
