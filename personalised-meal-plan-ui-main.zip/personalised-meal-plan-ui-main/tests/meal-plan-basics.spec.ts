import { test, expect } from "@playwright/test";

test.beforeEach(async ({ page }) => {
  await page.goto("/meal-plan/basics");
});

test.describe("Meal plan basics page construction", () => {
  test("has logo", async ({ page }) => {
    await expect(page.getByLabel("AND", { exact: true })).toBeVisible();
  });

  test("has current step", async ({ page }) => {
    await expect(page.getByLabel("Meal plan progress")).toBeVisible();
    await expect(
      page.locator("nav[aria-label='Meal plan progress'] li:first-child"),
    ).toHaveAttribute("aria-current");
  });

  test("has input for dog name", async ({ page }) => {
    await expect(page.getByLabel("What is your dog's name?")).toBeVisible();
  });

  test("has inputs for dog age", async ({ page }) => {
    await expect(page.getByPlaceholder("Years")).toBeVisible();
    await expect(page.getByPlaceholder("Months")).toBeVisible();
  });

  test("has selector for dog sex", async ({ page }) => {
    await expect(page.getByLabel("Male", { exact: true })).toBeVisible();
    await expect(page.getByLabel("Female", { exact: true })).toBeVisible();
  });

  test("has input for dog breed", async ({ page }) => {
    await expect(page.getByPlaceholder("Choose your Breed")).toBeVisible();
  });

  test("has input for spayed/neutered", async ({ page }) => {
    await expect(page.getByLabel("Yes", { exact: true })).toBeVisible();
    await expect(page.getByLabel("No", { exact: true })).toBeVisible();
  });

  test("has back button", async ({ page }) => {
    await expect(page.getByLabel("BACK")).toBeVisible();
  });

  test("has continue button", async ({ page }) => {
    await expect(page.getByRole("button", { name: "CONTINUE" })).toBeVisible();
  });
});
