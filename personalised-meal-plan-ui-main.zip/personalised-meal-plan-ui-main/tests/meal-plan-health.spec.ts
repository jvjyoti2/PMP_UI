import { test, expect } from "@playwright/test";

test.beforeEach(async ({ page }) => {
  await page.goto("/meal-plan/health");
});

// test("has title", async ({ page }) => {
//   await expect(page).toHaveTitle("Health");
// });

test("has logo", async ({ page }) => {
  await expect(
    page.getByRole("img", { name: "AND", exact: true }),
  ).toBeVisible();
});

test("has input for working dog", async ({ page }) => {
  await expect(page.getByText(/Is [a-z]* a working dog\?/i)).toBeVisible();
});

test("has info box for working dog", async ({ page }) => {
  await expect(
    page.getByText("Understand what working dog means and why this matters."),
  ).toBeVisible();
});

test("has back button", async ({ page }) => {
  await expect(page.getByLabel("BACK")).toBeVisible();
});

test("has continue button", async ({ page }) => {
  await expect(page.getByRole("button", { name: "CONTINUE" })).toBeVisible();
});
