import { test, expect } from "@playwright/test";

test.beforeEach(async ({ page }) => {
  await page.goto("/meal-plan/nutrition");
});

test("has logo", async ({ page }) => {
  await expect(
    page.getByRole("img", { name: "AND", exact: true }),
  ).toBeVisible();
});
