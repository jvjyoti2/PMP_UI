import { test, expect } from "@playwright/test";

test.describe("Full Journey", () => {
  test("can fill out form happy path", async ({ page }) => {
    await page.goto("");
    await page.getByText("Get started", { exact: true }).click();

    //trigger the errors
    await page.getByRole("button", { name: "CONTINUE" }).click();
    await expect(page.getByText("This field is required")).toHaveCount(4);

    //fill out the form
    await page.fill("input[name=dog_name]", "Buddy");
    await page.fill("input[name=dog_age_years]", "3");
    await page.fill("input[name=dog_age_months]", "6");
    await page.getByText("Male", { exact: true }).click();
    await page.fill("input[id=dog-breed]", "Golden Retriever");
    await page.getByText("Yes", { exact: true }).click();
    await page.getByRole("button", { name: "CONTINUE" }).click();
    await page.waitForLoadState("networkidle");
  });
});
