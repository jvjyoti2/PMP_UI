import colors from "tailwindcss/colors";

/**
 * See https://tailwindcss.com/docs/configuration.
 * @type {import("tailwindcss").Config}
 */
const tailwindConfig = {
  content: [
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    /**
     * Defined in src/app/global.css.
     */
    colors: {
      transparent: "transparent",
      current: "currentColor",
      white: "white",
      // See https://tailwindcss.com/docs/customizing-colors#using-css-variables.
      primary: "rgb(var(--color-primary) / <alpha-value>)",
      hover: "rgb(var(--color-hover) / <alpha-value>)",
      blue: "rgb(var(--color-blue) / <alpha-value>)",
      purple: "rgb(var(--color-purple) / <alpha-value>)",
      yellow: "rgb(var(--color-yellow) / <alpha-value>)",
      green: "rgb(var(--color-green) / <alpha-value>)",
      pink: "rgb(var(--color-pink) / <alpha-value>)",
      charcoal: "rgb(var(--color-charcoal) / <alpha-value>)",
      neutral: colors.neutral, // charcoal is approximately neutral-750
    },
    /**
     * Defined in src/app/layout.tsx.
     */
    fontFamily: {
      sans: ["var(--font-roboto)"],
      display: ["var(--font-poppins)"],
    },
    extend: {},
  },
  plugins: [],
};

export default tailwindConfig;
