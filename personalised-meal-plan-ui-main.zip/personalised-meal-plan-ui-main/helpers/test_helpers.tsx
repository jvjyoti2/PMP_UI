import { jest } from "@jest/globals";
import { Provider } from "jotai";
import { useHydrateAtoms } from "jotai/utils";
import { basicStateInterface } from "@/app/jotai/atoms";

export const mockRoutingProps = { onBack: jest.fn(), onSubmit: jest.fn() };

type JotaiTestProviderProps = {
  initialValues: any;
  children: React.ReactNode;
};

const HydrateAtoms = ({ initialValues, children }: JotaiTestProviderProps) => {
  useHydrateAtoms(initialValues);
  return children;
};

export const TestProvider = ({
  initialValues,
  children,
}: JotaiTestProviderProps) => {
  return (
    <Provider>
      <HydrateAtoms initialValues={initialValues}>{children}</HydrateAtoms>
    </Provider>
  );
};

export const basicTestStateValues: basicStateInterface = {
  dog_name: "testDogName",
  dog_age_years: null,
  dog_age_months: null,
  dog_breed: "",
  dog_sex: "F",
  dog_sterilised: "false",
};
